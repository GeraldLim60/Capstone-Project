//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test.rc
//
#define IDS_TEST_STRING1 51
#define IDS_TEST_STRING2 52
#define IDS_TEST_STRING3 53
#define IDS_TEST_STRING4 54
#define IDS_TEST_STRING5 55
#define IDS_TEST_STRING6 56
#define IDS_TEST_STRING7 57
#define IDD_TEST_DIALOG1 101
#define IDD_TEST_DIALOG2 102
#define IDB_PYTHON 103
#define IDI_PYTHON 105
#define IDD_TEST_DIALOG3 105
#define IDC_EDIT1 1000
#define IDC_CHECK1 1001
#define IDC_EDIT2 1001
#define IDC_COMBO1 1002
#define IDC_SPIN1 1003
#define IDC_PROGRESS1 1004
#define IDC_SLIDER1 1005
#define IDC_LIST1 1006
#define IDC_TREE1 1007
#define IDC_TAB1 1008
#define IDC_ANIMATE1 1009
#define IDC_RICHEDIT1 1010
#define IDC_DATETIMEPICKER1 1011
#define IDC_MONTHCALENDAR1 1012
#define IDC_SCROLLBAR1 1013
#define IDC_SCROLLBAR2 1014
#define IDC_LIST2 1015
#define IDC_HELLO 1016
#define IDC_HELLO2 1017

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE 107
#define _APS_NEXT_COMMAND_VALUE 40002
#define _APS_NEXT_CONTROL_VALUE 1018
#define _APS_NEXT_SYMED_VALUE 101
#endif
#endif
